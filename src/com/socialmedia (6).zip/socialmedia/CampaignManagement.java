package com.socialmedia;

// Interface
public interface CampaignManagement {
    void createCampaign(String campaignName, String platform);
    void trackCampaignPerformance();
}