package com.socialmedia;

import java.util.ArrayList;
import java.util.Random;

public class Influencer extends User {
    private int engagement;
    private int ageDemographic;
    private int followers;
    private ArrayList<Contract> receivedContracts; // To manage contracts received

    public Influencer(String username, String password, String email, String role, String niche) {
        super(username, password, email, role, niche);

        // Generate random values for Influencer attributes
        Random random = new Random();
        this.engagement = random.nextInt(100000000) + 1; // 1 to 100,000,000
        this.ageDemographic = random.nextInt(78) + 13; // 13 to 90
        this.followers = random.nextInt(9999999) + 1; // 1 to 9,999,999
        this.receivedContracts = new ArrayList<>();
    }

    public void receiveContract(Contract contract) {
        receivedContracts.add(contract);
        System.out.println(getUsername() + " received a contract for campaign: " + contract.getCampaignName());
    }

    public void viewContracts() {
        System.out.println("Contracts received by " + getUsername() + ":");
        for (int i = 0; i < receivedContracts.size(); i++) {
            Contract contract = receivedContracts.get(i);
            System.out.println((i + 1) + ". Campaign: " + contract.getCampaignName() + " (Status: " + contract.getStatus() + ")");
        }
    }

    public void acceptContract(int contractIndex) {
        if (contractIndex < 0 || contractIndex >= receivedContracts.size()) {
            System.out.println("Invalid contract selection.");
            return;
        }
        Contract contract = receivedContracts.get(contractIndex);
        contract.accept();
        contract.getCampaign().addInfluencer(this);
        System.out.println("You have accepted the contract for campaign: " + contract.getCampaignName());
    }

    public void rejectContract(int contractIndex) {
        if (contractIndex < 0 || contractIndex >= receivedContracts.size()) {
            System.out.println("Invalid contract selection.");
            return;
        }
        Contract contract = receivedContracts.get(contractIndex);
        contract.reject();
        System.out.println("You have rejected the contract for campaign: " + contract.getCampaignName());
    }

    public int getEngagement() {
        return engagement;
    }

    public int getAgeDemographic() {
        return ageDemographic;
    }

    public int getFollowers() {
        return followers;
    }

    @Override
    public void viewDashboard() {
        System.out.println("Influencer Dashboard - Collaborate on campaigns and manage contracts");
    }
}