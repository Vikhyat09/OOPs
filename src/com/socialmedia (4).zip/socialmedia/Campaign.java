package com.socialmedia;

import java.util.ArrayList;

public class Campaign {
    private String name;
    private String platform;
    private ArrayList<Influencer> acceptedInfluencers;

    public Campaign(String name, String platform) {
        this.name = name;
        this.platform = platform;
        this.acceptedInfluencers = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getPlatform() {
        return platform;
    }

    public void addInfluencer(Influencer influencer) {
        acceptedInfluencers.add(influencer);
    }

    public ArrayList<Influencer> getAcceptedInfluencers() {
        return acceptedInfluencers;
    }
}