package com.socialmedia;

public class Contract {
    private BrandManager brandManager;
    private Influencer influencer;
    private Campaign campaign;
    private String status;

    public Contract(BrandManager brandManager, Influencer influencer, Campaign campaign) {
        this.brandManager = brandManager;
        this.influencer = influencer;
        this.campaign = campaign;
        this.status = "Pending";
    }

    public void accept() {
        status = "Accepted";
        System.out.println("Contract for " + campaign.getName() + " accepted by " + influencer.getUsername());
    }

    public void reject() {
        status = "Rejected";
        System.out.println("Contract for " + campaign.getName() + " rejected by " + influencer.getUsername());
    }

    public String getCampaignName() {
        return campaign.getName();
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public String getStatus() {
        return status;
    }
}