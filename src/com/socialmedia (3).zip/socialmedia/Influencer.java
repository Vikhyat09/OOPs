package com.socialmedia;

import java.util.ArrayList;

public class Influencer extends User {
    private ArrayList<Contract> receivedContracts;

    public Influencer(String username, String password, String email, String role) {
        super(username, password, email, role);
        this.receivedContracts = new ArrayList<>();
    }

    public void receiveContract(Contract contract) {
        receivedContracts.add(contract);
        System.out.println(getUsername() + " received a contract for campaign: " + contract.getCampaignName());
    }

    public void viewContracts() {
        System.out.println("Contracts received by " + getUsername() + ":");
        for (int i = 0; i < receivedContracts.size(); i++) {
            Contract contract = receivedContracts.get(i);
            System.out.println((i + 1) + ". Campaign: " + contract.getCampaignName() + " (Status: " + contract.getStatus() + ")");
        }
    }

    public void acceptContract(int contractIndex) {
        if (contractIndex < 0 || contractIndex >= receivedContracts.size()) {
            System.out.println("Invalid contract selection.");
            return;
        }
        Contract contract = receivedContracts.get(contractIndex);
        contract.accept();
        contract.getCampaign().addInfluencer(this);
        System.out.println("You have accepted the contract for campaign: " + contract.getCampaignName());
    }

    public void rejectContract(int contractIndex) {
        if (contractIndex < 0 || contractIndex >= receivedContracts.size()) {
            System.out.println("Invalid contract selection.");
            return;
        }
        Contract contract = receivedContracts.get(contractIndex);
        contract.reject();
        System.out.println("You have rejected the contract for campaign: " + contract.getCampaignName());
    }

    @Override
    public void viewDashboard() {
        System.out.println("Influencer Dashboard - Collaborate on campaigns and manage contracts");
    }
}