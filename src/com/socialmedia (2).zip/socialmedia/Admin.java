package com.socialmedia;

import java.util.ArrayList;

public class Admin extends User {
    private ArrayList<User> userList;

    public Admin(String username, String password, String email) {
        super(username, password, email, "Admin");
        this.userList = new ArrayList<>();
    }

    public void addUser(String username, String password, String email, String role) {
        User newUser;
        switch (role) {
            case "Admin":
                newUser = new Admin(username, password, email);
                break;
            case "BrandManager":
                newUser = new BrandManager(username, password, email);
                break;
            case "Influencer":
                newUser = new Influencer(username, password, email, role);
                break;
            default:
                System.out.println("Invalid role. User not created.");
                return;
        }
        userList.add(newUser);
        System.out.println("User added: " + username + " with role: " + role);
    }

    public void removeUser(String username) {
        User userToRemove = null;
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                userToRemove = user;
                break;
            }
        }
        if (userToRemove != null) {
            userList.remove(userToRemove);
            System.out.println("User removed: " + username);
        } else {
            System.out.println("User not found: " + username);
        }
    }

    public void viewAllUsers() {
        System.out.println("All registered users:");
        for (User user : userList) {
            System.out.println("- Username: " + user.getUsername() + ", Role: " + user.getRole());
        }
    }

    @Override
    public void viewDashboard() {
        System.out.println("Admin Dashboard - Manage Users and View Platform Analytics");
    }
}