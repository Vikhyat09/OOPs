package com.socialmedia;

public class Contract {
    private BrandManager brandManager;
    private Influencer influencer;
    private String campaignName;
    private String status;

    public Contract(BrandManager brandManager, Influencer influencer, String campaignName) {
        this.brandManager = brandManager;
        this.influencer = influencer;
        this.campaignName = campaignName;
        this.status = "Pending";
    }

    public void accept() {
        status = "Accepted";
        System.out.println("Contract for " + campaignName + " accepted by " + influencer.getUsername());
    }

    public void reject() {
        status = "Rejected";
        System.out.println("Contract for " + campaignName + " rejected by " + influencer.getUsername());
    }

    public String getCampaignName() {
        return campaignName;
    }
}