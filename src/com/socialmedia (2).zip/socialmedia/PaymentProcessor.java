package com.socialmedia;

// Wrapper class usage for Double
public class PaymentProcessor {
    public void processPayment(String influencer, Double amount) {
        System.out.println("Payment of $" + amount + " sent to " + influencer);
    }
}