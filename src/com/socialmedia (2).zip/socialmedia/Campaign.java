package com.socialmedia;

public class Campaign {
    private String name;
    private String platform;

    public Campaign(String name, String platform) {
        this.name = name;
        this.platform = platform;
    }

    public String getName() {
        return name;
    }

    public String getPlatform() {
        return platform;
    }
}