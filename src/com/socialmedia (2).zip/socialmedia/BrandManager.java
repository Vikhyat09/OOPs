package com.socialmedia;

import java.util.ArrayList;

public class BrandManager extends User {
    private ArrayList<Campaign> myCampaigns;

    public BrandManager(String username, String password, String email) {
        super(username, password, email, "BrandManager");
        this.myCampaigns = new ArrayList<>();
    }

    public void createCampaign(String name, String platform) {
        Campaign campaign = new Campaign(name, platform);
        myCampaigns.add(campaign);
        System.out.println("Created campaign: " + name + " on " + platform);
    }

    public void listCampaigns() {
        System.out.println("Campaigns created by " + getUsername() + ":");
        for (Campaign campaign : myCampaigns) {
            System.out.println("- " + campaign.getName() + " on " + campaign.getPlatform());
        }
    }

    public void offerContract(Influencer influencer, String campaignName) {
        Campaign targetCampaign = getCampaignByName(campaignName);
        if (targetCampaign == null) {
            System.out.println("Campaign not found: " + campaignName);
            return;
        }

        Contract contract = new Contract(this, influencer, campaignName);
        influencer.receiveContract(contract);
        System.out.println("Contract offered to " + influencer.getUsername() + " for campaign: " + campaignName);
    }

    private Campaign getCampaignByName(String campaignName) {
        for (Campaign campaign : myCampaigns) {
            if (campaign.getName().equals(campaignName)) {
                return campaign;
            }
        }
        return null;
    }

    @Override
    public void viewDashboard() {
        System.out.println("Brand Manager Dashboard - Manage Campaigns and Contracts");
    }
}