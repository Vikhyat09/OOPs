package com.socialmedia;

public class Influencer extends User {
    public Influencer(String username, String password, String email, String role) {
        super(username, password, email, role);
    }

    public void receiveContract(Contract contract) {
        System.out.println(getUsername() + " received contract for campaign: " + contract.getCampaignName());
    }

    @Override
    public void viewDashboard() {
        System.out.println("Influencer Dashboard - Collaborate on campaigns and contracts");
    }
}