package com.socialmedia;

import java.util.HashMap;
import java.util.Map;

public class LoginManager {
    private Map<String, String> userCredentials = new HashMap<>();

    public void register(String email, String password) {
        // Simple hash simulation for secure password storage
        userCredentials.put(email, Integer.toHexString(password.hashCode()));
    }

    public boolean login(String email, String password) {
        String hashedPassword = Integer.toHexString(password.hashCode());
        return userCredentials.containsKey(email) && userCredentials.get(email).equals(hashedPassword);
    }
}