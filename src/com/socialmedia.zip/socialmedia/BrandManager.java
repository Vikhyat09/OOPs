package com.socialmedia;

import java.util.ArrayList;

public class BrandManager extends User {
    private ArrayList<Campaign> myCampaigns;

    public BrandManager(String name, String email, String password) {
        super(name, email, password);
        this.myCampaigns = new ArrayList<>();
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Brand Manager - Manage Campaigns and Collaborations");
    }

    public void createCampaign(String campaignName, String platform) {
        Campaign campaign = new Campaign(campaignName, platform);
        myCampaigns.add(campaign);
        System.out.println("Campaign '" + campaignName + "' created on platform: " + platform);
    }

    public void listMyCampaigns() {
        System.out.println("Campaigns created by " + getName() + ":");
        for (Campaign campaign : myCampaigns) {
            System.out.println("- " + campaign.getName() + " on " + campaign.getPlatform());
        }
    }

    public void trackCampaignPerformance() {
        System.out.println("Tracking performance for campaigns created by " + getName() + ":");
        for (Campaign campaign : myCampaigns) {
            System.out.println("- Campaign: " + campaign.getName() + ", Status: " + campaign.getStatus());
        }
    }

    public void offerContract(Influencer influencer, String campaignName) {
        Campaign targetCampaign = getCampaignByName(campaignName);
        if (targetCampaign == null) {
            System.out.println("Campaign not found. Please create the campaign before offering a contract.");
            return;
        }

        Contract contract = new Contract(this, influencer, campaignName);
        influencer.receiveContract(contract);
        System.out.println("Contract offered to " + influencer.getName() + " for campaign: " + campaignName);
    }

    // Method to search for a campaign by its name
    public Campaign getCampaignByName(String campaignName) {
        for (Campaign campaign : myCampaigns) {
            if (campaign.getName().equals(campaignName)) {
                return campaign;
            }
        }
        return null; // Campaign not found
    }
}