package com.socialmedia;

import java.util.ArrayList;

public class Influencer extends User {
    private String niche;
    private int followerCount;
    private ArrayList<Contract> contractsReceived;

    public Influencer(String name, String email, String password, String niche, int followerCount) {
        super(name, email, password);
        this.niche = niche;
        this.followerCount = followerCount;
        this.contractsReceived = new ArrayList<>();
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Influencer - Collaborate on campaigns and promote products");
    }

    public void receiveContract(Contract contract) {
        contractsReceived.add(contract);
        System.out.println("New contract received for campaign: " + contract.getCampaignName());
    }

    public void viewContracts() {
        System.out.println("Contracts received by " + getName() + ":");
        for (Contract contract : contractsReceived) {
            System.out.println("- Contract ID: " + contract.getContractId() +
                               ", Campaign: " + contract.getCampaignName() +
                               ", Status: " + contract.getStatus());
        }
    }

    public void respondToContract(int contractId, boolean accept) {
        for (Contract contract : contractsReceived) {
            if (contract.getContractId() == contractId) {
                if (accept) {
                    contract.acceptContract();

                    // Automatically add the influencer to the campaign
                    BrandManager manager = contract.getBrandManager();
                    Campaign campaign = manager.getCampaignByName(contract.getCampaignName());
                    if (campaign != null) {
                        campaign.addParticipant(this);
                        System.out.println("You have been added to the campaign: " + campaign.getName());
                    } else {
                        System.out.println("Error: Campaign not found for contract.");
                    }
                } else {
                    contract.rejectContract();
                }
                return;
            }
        }
        System.out.println("No contract found with ID: " + contractId);
    }
}