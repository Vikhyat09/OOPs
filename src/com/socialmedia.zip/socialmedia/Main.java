package com.socialmedia;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        User[] users = new User[10];
        users[0] = new Admin("Alice", "admin@platform.com", "admin123");
        users[1] = new Influencer("Bob", "influencer@social.com", "techguru", "Tech", 100000);
        users[2] = new BrandManager("Charlie", "brand@company.com", "brandmaster");

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter email to log in:");
            String email = scanner.nextLine();
            System.out.println("Enter password:");
            String password = scanner.nextLine();

            User loggedInUser = null;
            for (User user : users) {
                if (user != null && user.getEmail().equals(email) && user.validatePassword(password)) {
                    loggedInUser = user;
                    break;
                }
            }

            if (loggedInUser == null) {
                System.out.println("Invalid email or password. Try again.");
                continue; // Go back to login prompt
            }

            System.out.println("Welcome " + loggedInUser.getName() + "!");
            loggedInUser.displayRole();

            if (loggedInUser instanceof BrandManager) {
                BrandManager manager = (BrandManager) loggedInUser;
                while (true) {
                    System.out.println("\nBrand Manager Actions:");
                    System.out.println("1. Create Campaign");
                    System.out.println("2. Offer Contract to Influencer");
                    System.out.println("3. View My Campaigns");
                    System.out.println("4. Track Campaign Performance");
                    System.out.println("5. Logout");

                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice) {
                        case 1:
                            System.out.println("Enter Campaign Name:");
                            String campaignName = scanner.nextLine();
                            System.out.println("Enter Platform:");
                            String platform = scanner.nextLine();
                            manager.createCampaign(campaignName, platform);
                            break;

                        case 2:
                            System.out.println("Enter Influencer Email:");
                            String influencerEmail = scanner.nextLine();
                            User foundUser = null;
                            for (User user : users) {
                                if (user != null && user.getEmail().equals(influencerEmail) && user instanceof Influencer) {
                                    foundUser = user;
                                    break;
                                }
                            }
                            if (foundUser != null) {
                                System.out.println("Enter Campaign Name:");
                                campaignName = scanner.nextLine();
                                manager.offerContract((Influencer) foundUser, campaignName);
                            } else {
                                System.out.println("Influencer not found.");
                            }
                            break;

                        case 3:
                            manager.listMyCampaigns();
                            break;

                        case 4:
                            manager.trackCampaignPerformance();
                            break;

                        case 5:
                            System.out.println("Logging out...");
                            break;

                        default:
                            System.out.println("Invalid choice. Try again.");
                    }

                    if (choice == 5) {
                        break; // Exit to login screen
                    }
                }
            } else if (loggedInUser instanceof Influencer) {
                Influencer influencer = (Influencer) loggedInUser;
                while (true) {
                    System.out.println("\nInfluencer Actions:");
                    System.out.println("1. View Contracts");
                    System.out.println("2. Respond to Contract");
                    System.out.println("3. Logout");

                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice) {
                        case 1:
                            influencer.viewContracts();
                            break;

                        case 2:
                            System.out.println("Enter Contract ID to Respond:");
                            int contractId = scanner.nextInt();
                            scanner.nextLine(); // Consume newline
                            System.out.println("Accept Contract? (true/false):");
                            boolean accept = scanner.nextBoolean();
                            scanner.nextLine(); // Consume newline
                            influencer.respondToContract(contractId, accept);
                            break;

                        case 3:
                            System.out.println("Logging out...");
                            break;

                        default:
                            System.out.println("Invalid choice. Try again.");
                    }

                    if (choice == 3) {
                        break; // Exit to login screen
                    }
                }
            }
        }
    }
}