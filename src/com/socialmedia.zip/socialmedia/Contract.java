package com.socialmedia;

public class Contract {
    private static int contractCounter = 1; // To generate unique contract IDs
    private final int contractId;
    private final BrandManager brandManager;
    private final Influencer influencer;
    private final String campaignName;
    private String status; // "Pending", "Accepted", "Rejected"

    public Contract(BrandManager brandManager, Influencer influencer, String campaignName) {
        this.contractId = contractCounter++;
        this.brandManager = brandManager;
        this.influencer = influencer;
        this.campaignName = campaignName;
        this.status = "Pending"; // Default status
    }

    public void acceptContract() {
        if (status.equals("Pending")) {
            status = "Accepted";
            System.out.println("Contract ID " + contractId + " has been accepted by " + influencer.getName());
        } else {
            System.out.println("Contract ID " + contractId + " cannot be accepted. Current status: " + status);
        }
    }

    public void rejectContract() {
        if (status.equals("Pending")) {
            status = "Rejected";
            System.out.println("Contract ID " + contractId + " has been rejected by " + influencer.getName());
        } else {
            System.out.println("Contract ID " + contractId + " cannot be rejected. Current status: " + status);
        }
    }

    public int getContractId() {
        return contractId;
    }

    public BrandManager getBrandManager() {
        return brandManager;
    }

    public String getCampaignName() {
        return campaignName;
    }

    public String getStatus() {
        return status;
    }
}