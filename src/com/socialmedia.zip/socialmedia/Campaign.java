package com.socialmedia;

import java.util.ArrayList;

public class Campaign {
    private String name;
    private String platform;
    private String status;
    private ArrayList<User> participants;

    public Campaign(String name, String platform) {
        this.name = name;
        this.platform = platform;
        this.status = "Active";
        this.participants = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getPlatform() {
        return platform;
    }

    public String getStatus() {
        return status;
    }

    public void addParticipant(User user) {
        participants.add(user);
    }
}