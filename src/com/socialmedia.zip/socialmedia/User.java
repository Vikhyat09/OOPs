package com.socialmedia;

public abstract class User {
    private String name;
    private String email;
    private String password; // Plain-text password (not secure)

    public User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    // Validates the password by comparing it directly with the stored password
    public boolean validatePassword(String password) {
        return this.password.equals(password);
    }

    public abstract void displayRole();
}