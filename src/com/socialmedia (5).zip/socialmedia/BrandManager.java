package com.socialmedia;

import java.util.ArrayList;

public class BrandManager extends User {
    private ArrayList<Campaign> myCampaigns; // List of campaigns created by the BrandManager

    // Constructor
    public BrandManager(String username, String password, String email, String role, String niche) {
        super(username, password, email, role, niche);
        this.myCampaigns = new ArrayList<>();
    }

    // Method to create a new campaign
    public void createCampaign(String name, String platform) {
        Campaign campaign = new Campaign(name, platform);
        myCampaigns.add(campaign);
        System.out.println("Campaign '" + name + "' created successfully on platform: " + platform);
    }

    // Method to list all campaigns created by the BrandManager
    public void listCampaigns() {
        System.out.println("Campaigns created by " + getUsername() + ":");
        if (myCampaigns.isEmpty()) {
            System.out.println("No campaigns created yet.");
        } else {
            for (Campaign campaign : myCampaigns) {
                System.out.println("- Campaign: " + campaign.getName() + " on " + campaign.getPlatform());

                // Display associated influencers
                ArrayList<Influencer> influencers = campaign.getInfluencers();
                if (influencers.isEmpty()) {
                    System.out.println("  No influencers associated yet.");
                } else {
                    System.out.println("  Influencers:");
                    for (Influencer influencer : influencers) {
                        System.out.println("    - " + influencer.getUsername());
                    }
                }
            }
        }
    }

    // Method to offer a contract to an influencer for a specific campaign
    public void offerContract(Influencer influencer, String campaignName) {
        Campaign targetCampaign = getCampaignByName(campaignName);
        if (targetCampaign == null) {
            System.out.println("Campaign not found: " + campaignName);
            return;
        }

        Contract contract = new Contract(this, influencer, targetCampaign);
        influencer.receiveContract(contract); // Send the contract to the influencer
        System.out.println("Contract offered to " + influencer.getUsername() + " for campaign: " + campaignName);
    }

    // Method to find a campaign by its name
    private Campaign getCampaignByName(String campaignName) {
        for (Campaign campaign : myCampaigns) {
            if (campaign.getName().equalsIgnoreCase(campaignName)) {
                return campaign;
            }
        }
        return null;
    }

    // Method to view all contracts offered to influencers for campaigns created by the BrandManager
    public void viewContracts() {
        System.out.println("Contracts for campaigns created by " + getUsername() + ":");
        boolean hasContracts = false;

        for (Campaign campaign : myCampaigns) {
            ArrayList<Influencer> influencers = campaign.getInfluencers();
            if (!influencers.isEmpty()) {
                System.out.println("- Campaign: " + campaign.getName());
                for (Influencer influencer : influencers) {
                    System.out.println("    - Influencer: " + influencer.getUsername());
                }
                hasContracts = true;
            }
        }

        if (!hasContracts) {
            System.out.println("No contracts offered yet.");
        }
    }

    @Override
    public void viewDashboard() {
        System.out.println("Brand Manager Dashboard - Manage Campaigns and Contracts");
    }
}