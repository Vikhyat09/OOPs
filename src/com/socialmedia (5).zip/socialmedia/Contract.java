package com.socialmedia;

public class Contract {
    private BrandManager brandManager;
    private Influencer influencer;
    private Campaign campaign;
    private String status; // Accepted, Rejected, Pending

    // Constructor
    public Contract(BrandManager brandManager, Influencer influencer, Campaign campaign) {
        this.brandManager = brandManager;
        this.influencer = influencer;
        this.campaign = campaign;
        this.status = "Pending";
    }

    // Getter for the campaign name
    public String getCampaignName() {
        return campaign.getName();
    }

    // Getter for the campaign
    public Campaign getCampaign() {
        return campaign;
    }

    // Method to accept the contract
    public void accept() {
        this.status = "Accepted";
    }

    // Method to reject the contract
    public void reject() {
        this.status = "Rejected";
    }

    // Getter for the status of the contract
    public String getStatus() {
        return status;
    }
}