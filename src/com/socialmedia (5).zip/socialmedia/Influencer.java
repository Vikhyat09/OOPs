package com.socialmedia;

import java.util.ArrayList;
import java.util.Random;

public class Influencer extends User {
    private final int engagement; // Final to prevent re-assignment
    private final int ageDemographic; // Final to prevent re-assignment
    private final int followers; // Final to prevent re-assignment
    private ArrayList<Contract> receivedContracts; // To manage contracts received

    // Constructor
    public Influencer(String username, String password, String email, String role, String niche) {
        super(username, password, email, role, niche);

        // Assign random values only once in the constructor
        Random random = new Random();
        this.engagement = random.nextInt(100000000) + 1; // 1 to 100,000,000
        this.ageDemographic = random.nextInt(78) + 13; // 13 to 90
        this.followers = random.nextInt(9999999) + 1; // 1 to 9,999,999
        this.receivedContracts = new ArrayList<>();
    }

    // Method to receive a contract
    public void receiveContract(Contract contract) {
        receivedContracts.add(contract);
        System.out.println(getUsername() + " received a contract for campaign: " + contract.getCampaignName());
    }

    // Method to view all received contracts
    public void viewContracts() {
        System.out.println("Contracts received by " + getUsername() + ":");
        if (receivedContracts.isEmpty()) {
            System.out.println("No contracts received yet.");
        } else {
            for (int i = 0; i < receivedContracts.size(); i++) {
                Contract contract = receivedContracts.get(i);
                System.out.println((i + 1) + ". Campaign: " + contract.getCampaignName() + " (Status: " + contract.getStatus() + ")");
            }
        }
    }

    // Method to accept a contract
    public void acceptContract(int contractIndex) {
        if (contractIndex < 0 || contractIndex >= receivedContracts.size()) {
            System.out.println("Invalid contract selection.");
            return;
        }
        Contract contract = receivedContracts.get(contractIndex);
        contract.accept();

        // Add this influencer to the associated campaign
        Campaign campaign = contract.getCampaign();
        campaign.addInfluencer(this);

        System.out.println("You have accepted the contract for campaign: " + campaign.getName());
    }

    // Method to reject a contract
    public void rejectContract(int contractIndex) {
        if (contractIndex < 0 || contractIndex >= receivedContracts.size()) {
            System.out.println("Invalid contract selection.");
            return;
        }
        Contract contract = receivedContracts.get(contractIndex);
        contract.reject();
        System.out.println("You have rejected the contract for campaign: " + contract.getCampaignName());
    }

    // Getters for Influencer attributes
    public int getEngagement() {
        return engagement;
    }

    public int getAgeDemographic() {
        return ageDemographic;
    }

    public int getFollowers() {
        return followers;
    }

    // Method to view influencer details
    public void viewDetails() {
        System.out.println("\nInfluencer Details:");
        System.out.println("Username: " + getUsername());
        System.out.println("Email: " + getEmail());
        System.out.println("Niche: " + getNiche());
        System.out.println("Engagement: " + engagement);
        System.out.println("Age Demographic: " + ageDemographic);
        System.out.println("Followers: " + followers);
    }

    // Dashboard method for Influencer
    @Override
    public void viewDashboard() {
        System.out.println("Influencer Dashboard - Collaborate on campaigns and manage contracts");
    }
}